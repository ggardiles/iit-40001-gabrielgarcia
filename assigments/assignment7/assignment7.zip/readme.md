# Assignment 7

Users Node.JS API without persistance.

### Install dependencies
```sh
$ npm i
```

### Run server
```sh
$ npm start
```

